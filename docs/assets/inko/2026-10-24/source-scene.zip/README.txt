Inko 可编辑笔迹包（inko-scene v1）
==================================

这是什么
--------
这是一次 Inko 生成结果的「逐字版」。除了整页图片，这里把每个字单独存了下来：
模型写出的原样字形（还没加笔的效果），以及它在页面上的位置、大小和角度。
有了它，可以在本地挪字、收紧字距、换笔、让行首自然错开，再重新导出整页。
不用重新生成，也不再花钱；已经写好的字一个都不会变。

包里有什么
----------
  scene.json            主文档：页面、每个字、行、笔、纸、标识、AIGC 字段
  sprites/page-N.png    第 N 页的字形拼板（8 位灰度，255 = 白纸，墨迹是原样的）
  paper/page-N.png      第 N 页的纸（不带墨迹和标识）。纯色纸没有这张图，只在 scene.json
                        里记颜色；几页用同一张纸时共用一个文件
  label.png             显式标识「AI生成 · Inko」，与服务端画的一模一样（RGBA）
  README.txt            本说明

怎么编辑
--------
最简单的办法：把这个 scene.zip 交给你的 AI 助手，直接说想怎么改，比如
「第三行字距太松」「每行开头太整齐了」「换成蓝色中性笔」。

装了 inko-handwriting skill 的话，也可以自己运行它的 scripts/scene.py
（不用手动解压，第一次运行会解压到同名文件夹）：
  python scene.py editor  scene.zip                  打开本地网页编辑器：拖字、框选、缩放、换笔，改完点「保存」
  python scene.py render  scene.zip -o out/ --pdf    按修改导出 PNG 和 PDF（自动带标识）
  python scene.py inspect scene.zip                  检查字距过大、粗细不一、重叠、出界等问题
修改记在 edits.json 里（与 scene.json 放在一起），原始字形不会被改动，随时可以撤销。

AI 标识必须保留
---------------
这是 AI 生成的内容。按国家标准 GB 45438-2025《网络安全技术 人工智能生成合成内容标识方法》，
从本包导出、展示或发给别人的任何图片、PDF、截图，都必须同时带：
  - 显式标识「AI生成 · Inko」（label.png，文字高度不小于图片短边的 5%）；
  - 隐式标识，即文件里的 AIGC 元数据（scene.json 的 "aigc" 字段，ProduceID = 该页的 aigc_id）。
用 inko-handwriting skill 导出时，两者都会自动加上。
字形拼板本身不带显式标识：不要单独发布拼板，也不要发布去掉标识的重新渲染结果。

技术说明：几何（单位都是页面像素，300 dpi，原点在左上角，y 向下）
------------------------------------------------------------------
glyph.sprite.rect = [x, y, w, h]：这个字在拼板里的位置。
glyph.m = [a, b, c, d, e, f]：把小图坐标 (u, v) 映到页面：
    x = a*u + b*v + c,   y = d*u + e*v + f
坐标是连续的：小图像素 k 占 [k, k+1)，中心在 k+0.5。
渲染：对每个页面像素中心反解 m，在小图里双线性取值（小图外 = 纸，255），除以 255，
再与这一层（白 = 1.0）取最小值。等价于 PIL Image.transform(AFFINE, BILINEAR, fillcolor=255)，
data = inverse(m)，再加上这一块在页面上的像素偏移。
glyph.anchor = 基线锚点（旋转、缩放都绕它）；glyph.size = 名义字高；
glyph.adv = [x0, x1]：这个字在行里的前进宽度；
glyph.ink = [x0, y0, x1, y1]：实测墨迹边界（比 0.82 深的像素；x1 / y1 不含）。
排版类修改按 anchor / size / adv 算；ink 反映真实的字间空隙。
glyph.cell = true：这个字写在格子里（稿纸 / 方格），位置由格子决定，调字距时不动它（没有这个字段 = 不在格子里）。
i / j = 原文 "text" 里的 UTF-16 区间（i >= own_base 时是额外文字框里的字：
k, off = divmod(i - own_base, 100000)，区间在 own_texts[k] 里）。

技术说明：笔与整页合成
----------------------
字按 page.layers 的顺序分到各个墨迹层（glyph.layer）。每层是一张白页（1.0），
把这一层的字取最小值贴上去，再施加这一层的笔（pen 为 null 时用全局 "pen"；默认笔 = 不处理），
然后按顺序正片叠底到纸上：
    out = round(paper * (1 - a * (1 - ink_rgb/255)))   （默认笔：round(paper * layer)）
笔的算法 = Inko worker 的 pen.py，按 pen_px_per_mm（11.8095 px/mm）计算，噪声原点 = 页面原点。
最后贴标识：page.paste(label.png, label.xy, label.png)。
"gray" 为 true 表示服务端把页面存成了 8 位灰度：整页（含标识）合成完再 PIL Image.convert("L")。
